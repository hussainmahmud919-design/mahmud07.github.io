
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Skills from './components/Skills';
import Portfolio from './components/Portfolio';
import IdeaGenerator from './components/IdeaGenerator';
import Contact from './components/Contact';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen font-sans selection:bg-brand-primary selection:text-white overflow-x-hidden">
      <Navbar />
      <main>
        <section id="home">
          <Hero />
        </section>
        
        <section id="about" className="py-20 bg-[#0a0a0a]">
          <About />
        </section>

        <section id="skills" className="py-20 bg-brand-dark">
          <Skills />
        </section>

        <section id="portfolio" className="py-20 bg-[#0a0a0a]">
          <Portfolio />
        </section>

        <section id="ai-generator" className="py-20 bg-brand-dark">
          <IdeaGenerator />
        </section>

        <section id="contact" className="py-20 bg-[#0a0a0a]">
          <Contact />
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default App;
