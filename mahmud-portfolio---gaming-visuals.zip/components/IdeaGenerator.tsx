
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";

const IdeaGenerator: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [loading, setLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);

  const generateIdea = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setSuggestion(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am a gaming thumbnail designer. Suggest a creative, high-CTR thumbnail composition for a video about: "${topic}". Include color schemes, main focal points (characters/weapons), and text overlay ideas. Keep it professional and exciting.`,
        config: {
          temperature: 0.8,
          maxOutputTokens: 500,
        }
      });

      setSuggestion(response.text || "Could not generate an idea at the moment.");
    } catch (error) {
      console.error("AI Generation Error:", error);
      setSuggestion("Something went wrong. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-6">
      <div className="max-w-4xl mx-auto glass-effect p-12 rounded-[2rem] border-brand-primary/20 relative overflow-hidden">
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-brand-primary/10 blur-[80px] rounded-full"></div>
        
        <div className="relative z-10 text-center mb-10">
          <h2 className="text-3xl font-display font-black mb-4">AI Thumbnail Strategist</h2>
          <p className="text-white/60">Stuck on a concept? Let my AI assistant brainstorm a viral thumbnail idea for your next video.</p>
        </div>

        <div className="relative z-10 flex flex-col md:flex-row gap-4 mb-8">
          <input 
            type="text" 
            placeholder="e.g. 1v4 BGMI clutches with M416..." 
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="flex-1 bg-brand-dark/50 border border-white/10 rounded-2xl px-6 py-4 focus:outline-none focus:border-brand-primary transition-all text-white placeholder:text-white/30"
          />
          <button 
            onClick={generateIdea}
            disabled={loading}
            className="px-8 py-4 bg-brand-primary hover:bg-brand-primary/90 disabled:opacity-50 font-bold rounded-2xl transition-all flex items-center justify-center gap-2 min-w-[160px]"
          >
            {loading ? (
              <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
            ) : 'Generate Idea'}
          </button>
        </div>

        {suggestion && (
          <div className="relative z-10 bg-white/5 border border-white/10 p-8 rounded-2xl animate-in fade-in slide-in-from-bottom-4">
            <h3 className="text-brand-primary font-bold mb-4 uppercase text-xs tracking-widest flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-brand-primary"></span>
              Mahmud's AI Suggestion
            </h3>
            <div className="text-white/80 leading-relaxed whitespace-pre-wrap prose prose-invert max-w-none">
              {suggestion}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IdeaGenerator;
