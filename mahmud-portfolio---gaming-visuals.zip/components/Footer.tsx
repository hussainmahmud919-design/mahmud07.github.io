
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-dark border-t border-white/5 py-12">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
             <a href="#home" className="text-2xl font-display font-black tracking-tighter mb-2 block">
                <span className="bg-gradient-to-r from-brand-primary to-brand-secondary bg-clip-text text-transparent">MAHMUD</span>
             </a>
             <p className="text-white/40 text-sm">Elevating gaming content through professional design.</p>
          </div>
          
          <div className="flex gap-6">
            <a href="#" className="text-white/40 hover:text-brand-primary transition-colors">Instagram</a>
            <a href="#" className="text-white/40 hover:text-brand-primary transition-colors">YouTube</a>
            <a href="#" className="text-white/40 hover:text-brand-primary transition-colors">Discord</a>
            <a href="#" className="text-white/40 hover:text-brand-primary transition-colors">Behance</a>
          </div>

          <div className="text-white/40 text-sm">
            © {new Date().getFullYear()} Mahmud Visuals. All Rights Reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
