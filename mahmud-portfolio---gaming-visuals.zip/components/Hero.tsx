
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      {/* Background Decorations */}
      <div className="absolute top-0 left-0 w-full h-full -z-10">
        <div className="absolute top-1/4 -left-20 w-96 h-96 bg-brand-primary/20 blur-[100px] rounded-full"></div>
        <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-brand-secondary/20 blur-[100px] rounded-full"></div>
      </div>

      <div className="container mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-brand-primary font-display font-bold tracking-widest uppercase mb-4 text-sm md:text-base">
            Level Up Your Content
          </h2>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-display font-black leading-tight mb-6">
            Visuals that <br />
            <span className="bg-gradient-to-r from-brand-primary via-purple-500 to-brand-secondary bg-clip-text text-transparent">
              DOMINATE.
            </span>
          </h1>
          <p className="text-lg text-white/70 max-w-lg mb-8 leading-relaxed">
            I am Mahmud, a specialized Gaming Thumbnail Designer & Video Editor. 
            I help BGMI creators and Esports teams boost their CTR and viewer engagement 
            with high-impact visuals.
          </p>
          <div className="flex flex-wrap gap-4">
            <a 
              href="#portfolio" 
              className="px-8 py-4 rounded-xl bg-brand-primary font-bold text-white shadow-lg shadow-brand-primary/20 hover:bg-brand-primary/90 transition-all flex items-center gap-2"
            >
              View My Work
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </a>
            <a 
              href="#contact" 
              className="px-8 py-4 rounded-xl border border-white/20 font-bold hover:bg-white/5 transition-all"
            >
              Get a Quote
            </a>
          </div>
        </div>

        <div className="relative flex justify-center items-center">
          <div className="relative z-10 w-full max-w-md animate-float">
            <div className="absolute -inset-4 bg-gradient-to-r from-brand-primary to-brand-secondary opacity-30 blur-2xl rounded-2xl"></div>
            <img 
              src="https://i.postimg.cc/BQnLcqnn/img-(7).webp" 
              alt="Hero Preview" 
              className="relative rounded-2xl shadow-2xl border border-white/10 transform rotate-2 hover:rotate-0 transition-transform duration-500"
            />
            <div className="absolute -bottom-6 -right-6 glass-effect p-4 rounded-xl shadow-xl border border-white/10 hidden lg:block">
              <p className="text-brand-primary font-black text-2xl">+45%</p>
              <p className="text-xs text-white/60 font-semibold uppercase tracking-wider">Average CTR Increase</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
