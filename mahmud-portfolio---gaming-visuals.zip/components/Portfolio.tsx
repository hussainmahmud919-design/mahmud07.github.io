
import React, { useState } from 'react';

const Portfolio: React.FC = () => {
  const [filter, setFilter] = useState('All');

  const projects = [
    { id: 1, category: 'BGMI', title: 'Live Stream Master', img: 'https://i.postimg.cc/BQnLcqnn/img-(7).webp' },
    { id: 2, category: 'Esports', title: 'Scrims Showdown', img: 'https://i.postimg.cc/26HwT0hL/Picsart-25-12-22-17-10-17-123.jpg' },
    { id: 3, category: 'Anime', title: 'Cyberpunk Warrior', img: 'https://i.postimg.cc/FKNV4MxV/Picsart-26-01-22-01-48-20-305.png' },
    { id: 4, category: 'Esports', title: 'Championship Series', img: 'https://i.postimg.cc/yNxyfwXW/Picsart-26-01-22-22-52-17-411.jpg' },
  ];

  const categories = ['All', 'BGMI', 'Esports', 'Anime'];

  const filteredProjects = filter === 'All' ? projects : projects.filter(p => p.category === filter);

  return (
    <div className="container mx-auto px-6">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
        <div>
          <h2 className="text-4xl md:text-5xl font-display font-black uppercase">Portfolio</h2>
          <p className="text-white/50 mt-2">Latest visual experiments and client work.</p>
        </div>
        <div className="flex gap-2 bg-brand-dark p-2 rounded-2xl border border-white/5">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilter(cat)}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${filter === cat ? 'bg-brand-primary text-white shadow-lg shadow-brand-primary/20' : 'text-white/50 hover:text-white'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
        {filteredProjects.map(proj => (
          <div key={proj.id} className="group relative overflow-hidden rounded-3xl bg-brand-dark aspect-video">
            <img 
              src={proj.img} 
              alt={proj.title} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-80 group-hover:opacity-100" 
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-transparent to-transparent opacity-60"></div>
            <div className="absolute bottom-0 left-0 p-8 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
              <span className="text-brand-primary font-bold text-xs uppercase tracking-widest">{proj.category}</span>
              <h3 className="text-2xl font-display font-black text-white">{proj.title}</h3>
            </div>
            <button className="absolute top-6 right-6 w-12 h-12 glass-effect rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Portfolio;
