
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-6">
      <div className="grid md:grid-cols-2 gap-16 items-center">
        <div className="order-2 md:order-1">
          <div className="inline-block px-4 py-1 rounded-full bg-brand-primary/10 border border-brand-primary/20 text-brand-primary text-xs font-bold uppercase tracking-widest mb-6">
            The Story
          </div>
          <h2 className="text-4xl md:text-5xl font-display font-black mb-6">Expert in Gaming Storytelling through Design</h2>
          <p className="text-white/70 mb-6 leading-relaxed text-lg">
            I've spent years immersed in the BGMI and Indian Esports ecosystem, understanding exactly what catches a viewer's eye in a split second. A thumbnail isn't just an image; it's a promise of what's inside.
          </p>
          <p className="text-white/70 mb-8 leading-relaxed text-lg">
            Whether it's a high-intensity scrim poster or a cinematic YouTube thumbnail, my goal is to blend professional aesthetics with "click-worthy" psychological triggers.
          </p>
          
          <div className="grid grid-cols-2 gap-8">
            <div>
              <p className="text-3xl font-display font-black text-brand-primary">150+</p>
              <p className="text-sm text-white/50 font-bold uppercase">Projects Completed</p>
            </div>
            <div>
              <p className="text-3xl font-display font-black text-brand-secondary">50+</p>
              <p className="text-sm text-white/50 font-bold uppercase">Happy Creators</p>
            </div>
          </div>
        </div>

        <div className="order-1 md:order-2 grid grid-cols-2 gap-4">
          <div className="space-y-4">
             <img src="https://i.postimg.cc/26HwT0hL/Picsart-25-12-22-17-10-17-123.jpg" className="w-full h-64 object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-500" alt="Work 1" />
             <img src="https://i.postimg.cc/FKNV4MxV/Picsart-26-01-22-01-48-20-305.png" className="w-full h-48 object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-500" alt="Work 2" />
          </div>
          <div className="space-y-4 pt-8">
             <img src="https://i.postimg.cc/yNxyfwXW/Picsart-26-01-22-22-52-17-411.jpg" className="w-full h-48 object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-500" alt="Work 3" />
             <img src="https://i.postimg.cc/BQnLcqnn/img-(7).webp" className="w-full h-64 object-cover rounded-2xl grayscale hover:grayscale-0 transition-all duration-500" alt="Work 4" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
