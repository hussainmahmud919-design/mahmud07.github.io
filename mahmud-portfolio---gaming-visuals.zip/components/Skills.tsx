
import React from 'react';

const Skills: React.FC = () => {
  const services = [
    {
      title: "Thumbnail Design",
      desc: "Custom, high-CTR thumbnails for YouTube and streamers. Focused on lighting, typography, and focus points.",
      icon: "🎨"
    },
    {
      title: "Video Editing",
      desc: "Montages, funny moments, and highlight reels with cinematic color grading and sound design.",
      icon: "🎬"
    },
    {
      title: "Esports Branding",
      desc: "Professional tournament posters, scrim result templates, and team identity designs.",
      icon: "🏆"
    },
    {
      title: "Social Graphics",
      desc: "Banners, profile pictures, and stream overlays tailored for your brand personality.",
      icon: "📱"
    }
  ];

  return (
    <div className="container mx-auto px-6">
      <div className="text-center max-w-2xl mx-auto mb-16">
        <h2 className="text-4xl font-display font-black mb-4 uppercase tracking-tight">Services & Expertise</h2>
        <div className="h-1 w-20 bg-brand-primary mx-auto mb-6"></div>
        <p className="text-white/60">Everything you need to make your gaming content look world-class.</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {services.map((s, idx) => (
          <div key={idx} className="glass-effect p-8 rounded-3xl hover:border-brand-primary/50 transition-all group">
            <div className="text-4xl mb-6 group-hover:scale-110 transition-transform">{s.icon}</div>
            <h3 className="text-xl font-display font-bold mb-4">{s.title}</h3>
            <p className="text-white/60 text-sm leading-relaxed">{s.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Skills;
